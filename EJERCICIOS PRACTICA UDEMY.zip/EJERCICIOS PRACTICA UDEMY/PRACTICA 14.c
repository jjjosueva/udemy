/******************************************************************************
Escribir un programa que pida 4 cadenas por teclado y las muestre por la 
salida separadasa por un guion.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char cadena1[50], cadena2[50], cadena3[50], cadena4[50];
    printf("Introduce la cadena 1:\n ");
    gets(cadena1);//coge todo lo que hubiera en la entrada y lo mete en la cadena que le digo
    printf("Introduce la cadena 2:\n ");
    gets(cadena2);
    printf("Introduce la cadena 3:\n ");
    gets(cadena3);
    printf("Introduce la cadena 4:\n ");
    gets(cadena4);
    
    printf("%s-%s-%s-%s",cadena1,cadena2,cadena3,cadena4);//%s sirve para formatear las cadenas.

    return 0;
}
